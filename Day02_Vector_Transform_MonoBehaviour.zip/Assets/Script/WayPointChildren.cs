﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayPointChildren : MonoBehaviour
{

    public Transform WayPoint;
    public List<Transform> wayPointList;

    // Start is called before the first frame update
    void Start()
    {
        wayPointList = new List<Transform>();
        foreach (Transform t in WayPoint)
        wayPointList.Add(t);
        print(wayPointList.Count == 8);

    }

    // Update is called once per frame
    void Update()
    {
        wayPointList[0].GetComponent<MeshRenderer>().material.color = Color.yellow;
    }


}
